// Simple Express server stub for /api/preorder
// To run: npm install && node api/server.js
const express = require('express');
const app = express();
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(express.json());
app.use(express.static('public'));

// Basic rate limiter
const limiter = rateLimit({ windowMs: 60*1000, max: 10 });
app.use(limiter);

app.post('/api/preorder', (req, res) => {
  const {name,email,model,message} = req.body || {};
  if(!name || !email || !model) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  // TODO: Add server-side validation, sanitization, email send, and DB storage.
  console.log('Preorder received', {name,email,model,message});
  return res.status(200).json({ message: 'Request received. We will contact you shortly.' });
});

app.listen(PORT, ()=> console.log(`Server listening on ${PORT}`));
